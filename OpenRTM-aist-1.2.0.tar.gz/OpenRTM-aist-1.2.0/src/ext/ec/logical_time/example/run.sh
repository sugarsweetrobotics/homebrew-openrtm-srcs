#!/bin/sh

python TickApp.py
